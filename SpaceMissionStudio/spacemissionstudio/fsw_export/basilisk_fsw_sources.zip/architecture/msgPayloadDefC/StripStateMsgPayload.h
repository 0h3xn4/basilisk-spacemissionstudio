/*
 ISC License

 Copyright (c) 2026, Autonomous Vehicle Systems Lab, University of Colorado at Boulder

 Permission to use, copy, modify, and/or distribute this software for any
 purpose with or without fee is hereby granted, provided that the above
 copyright notice and this permission notice appear in all copies.

 THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

 */

#ifndef STRIPSTATE_MSG_H
#define STRIPSTATE_MSG_H

/*! @brief Message that defines the inertial location of the current target groundlocation on the central line of the strip and its velocity
 */
typedef struct {
    double r_LN_N[3]; //!< [m] Position vector of the current target w.r.t.the inertial origin in the inertial frame
    double r_LP_N[3]; //!< [m] Position vector of the current target w.r.t the planet center in the inertial frame
    double v_LN_N[3]; //!< [m/s] Velocity vector of the current target w.r.t the inertial origin in the inertial frame
    double v_LP_N[3]; //!< [m/s] Velocity vector of the current target w.r.t the planet center in the inertial frame

}StripStateMsgPayload;



#endif //STRIPSTATE_MSG_H
